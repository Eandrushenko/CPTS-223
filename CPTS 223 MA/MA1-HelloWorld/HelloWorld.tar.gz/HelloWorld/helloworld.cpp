/*
 *  Hello World test program
 *    -- Aaron Crandall, 2017
 */

#define _PROGRAM_NAME "Hello World w/ Username"

#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <string>
#include <pwd.h>

int main(void)
{
  register struct passwd *pw;
  register uid_t uid;
  std::string myname = "Anonymous 0123456789";  // Replace with your name and WSU ID!

  uid = geteuid ();
  pw = getpwuid (uid);

  if (pw)
  {
    std::cout << "Hello " << myname << " (" << pw->pw_name << ") this is your first program compiled for CptS223!" << std::endl;
  }
  else
  {
    std::cout << " [!] Very strange! I could not look up your username." << std::endl;
  }

  return 0;
}
