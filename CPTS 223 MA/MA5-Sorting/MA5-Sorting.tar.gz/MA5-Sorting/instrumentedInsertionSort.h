/***************************************************************************
 *
 *  Sorting algorithms and counting work - Insertion sort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented insertionsort
 *
 */

#ifndef __INSTRUMENTEDIS_H
#define __INSTRUMENTEDIS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void instrumentedInsertionSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: implement insertion sort plus logging compares, moves/swaps
	int i, key = 0, j = 0, size = a.size();
	for (i = 1; i < size; i++)
	{
		key = a[i];
		j = i - 1;
		
		while(size >= 0 && a[j] > key)
		{
			stats.compares++;
			stats.moves++;
			a[j+1] = a[j];
			j = j-1;
		}
		a[j+1] = key;
		stats.compares++;
	}
}




#endif
