/***************************************************************************
 *
 *  Sorting algorithms and counting work - Quicksort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented quicksort
 *
 */

#ifndef __INSTRUMENTEDQS_H
#define __INSTRUMENTEDQS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void QuickSort(vector<int> & a, int left, int right, SortStats & stats)
{
	int i = left, j = right;
	int temp = 0;
	int pivot = a[(left + right) / 2];

	//Parition
	while ( i <= j)
	{
		while(a[i] < pivot)
		{
			i++;
			stats.compares++;
		}
		while(a[j] > pivot)
		{
			j--;
			stats.compares++;
		}
		if(i <= j)
		{
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
			i++;
			j--;
			stats.compares++;
			stats.moves++;
		}
		stats.compares++;
	}
	
	if (left < j)
	{
		stats.compares++;
		QuickSort(a, left, j, stats);
	}
	if (i < right)
	{
		stats.compares++;
		QuickSort(a, i , right, stats);
	}

}

void instrumentedQuickSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: implement quicksort and track compares + moves
	int low = 0, high = a.size() - 1;
	QuickSort(a, low, high, stats);
}

#endif
