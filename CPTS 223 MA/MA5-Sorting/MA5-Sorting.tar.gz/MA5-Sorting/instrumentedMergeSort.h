/***************************************************************************
 *
 *  Sorting algorithms and counting work - Merge sort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented mergesort
 *
 */

#ifndef __INSTRUMENTEDMS_H
#define __INSTRUMENTEDMS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void Merge(vector<int> & a, int left, int right, int middle, SortStats & stats)
{
	int i = left, k = left, j = middle + 1;
	int c[500000];
	
	while( i <= middle && j <= right)
	{
		if(a[i] < a[j])
		{
			c[k] = a[i];
			k++;
			i++;
			stats.compares++;
		}
		else
		{
			c[k] = a[j];
			k++;
			j++;
			stats.compares + 2;
		}
	}

	while(i <= middle)
	{
		c[k] = a[i];
		k++;
		i++;
	}

	while(j <= right)
	{
		c[k] = a[j];
		k++;
		j++;
	}
	for(i = left; i < k; i++)
	{
		a[i] = c[i];
		stats.moves++;
	}
	

}

void MergeSort(vector<int> & a, int left, int right, SortStats & stats)
{
	if(left < right)
	{
		stats.compares++;
		int middle = (left + right) / 2;
		MergeSort(a, left, middle, stats);
		MergeSort(a, middle + 1, right, stats);
		Merge(a, left, right, middle, stats);
	}
}


void instrumentedMergeSort(vector<int> & a, SortStats & stats)
{
	int left = 0, right = a.size() - 1;
	MergeSort(a, left, right, stats);
}




#endif
