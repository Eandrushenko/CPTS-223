/***************************************************************************
 *
 *  Sorting algorithms and counting work - Merge sort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented mergesort
 *
 */

#ifndef __INSTRUMENTEDMS_H
#define __INSTRUMENTEDMS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void instrumentedMergeSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: Implement Merge Sort plus logging compares and moves/swaps
}


#endif
