
#ifndef __DICT_TESTS_H
#define __DICT_TESTS_H

#include <iostream>

using namespace std;

//**********************************************************************
void run_dictionary_tests() {

	cout << " [t] Dictionary tests begin." << endl;

	cout << "  [!!!] Currently no tests here, but Crandall needs to get you working now." << endl;
	cout << "  [!!!] Will send out a better test file later in the week." << endl;
	cout << "  [!!!] You'll just replace this one and more tests will show up. " << endl;

	cout << endl << " [t] Dictionary tests end." << endl;

}


#endif
